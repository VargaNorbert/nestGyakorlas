export default class UserDataDto {
  username: string;
  password: string;
}
